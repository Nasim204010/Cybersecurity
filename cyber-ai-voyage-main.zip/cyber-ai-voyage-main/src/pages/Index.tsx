import { Button } from "@/components/ui/button"
import { CyberCard } from "@/components/ui/cyber-card"
import { Navigation } from "@/components/layout/navigation"
import { ProgressIndicator } from "@/components/ui/progress-indicator"
import { useProgress } from "@/hooks/use-progress"
import { useNavigate } from "react-router-dom"
import { PlayCircle, Shield, Brain, Users, Search } from "lucide-react"

const Index = () => {
  const navigate = useNavigate()
  const { progress } = useProgress()
  const totalModules = 4
  const completedCount = progress.completedModules.length

  const features = [
    {
      icon: Brain,
      title: "AI-Powered Learning",
      description: "Interactive lessons using artificial intelligence to enhance cybersecurity awareness"
    },
    {
      icon: Shield,
      title: "Threat Simulation",
      description: "Practice identifying and responding to real-world cyber threats in a safe environment"
    },
    {
      icon: Search,
      title: "Detection Tools",
      description: "Learn about cutting-edge AI tools used for cybersecurity threat detection"
    },
    {
      icon: Users,
      title: "Social Engineering",
      description: "Understand and defend against human-based security attacks and manipulation"
    }
  ]

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <main className="pt-20 pb-12">
        <div className="container mx-auto px-4">
          {/* Hero Section */}
          <div className="text-center mb-16 animate-fade-in">
            <div className="inline-flex items-center space-x-2 mb-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-primary flex items-center justify-center neon-glow">
                <Brain className="w-7 h-7 text-primary-foreground" />
              </div>
              <h1 className="text-4xl md:text-6xl font-bold gradient-text">
                Cyber AI Awareness Hub
              </h1>
            </div>
            
            <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-3xl mx-auto leading-relaxed">
              Explore how Artificial Intelligence enhances cybersecurity awareness and training through interactive lessons, scenarios, and quizzes that simulate real cyber threats.
            </p>

            {completedCount > 0 && (
              <div className="mb-8 max-w-md mx-auto">
                <ProgressIndicator 
                  current={completedCount} 
                  total={totalModules}
                />
              </div>
            )}

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                onClick={() => navigate("/module1")}
                className="animate-glow-pulse hover:scale-105 transition-transform duration-300"
              >
                <PlayCircle className="w-5 h-5 mr-2" />
                {completedCount > 0 ? "Continue Learning" : "Start Your Journey"}
              </Button>
              <Button 
                size="lg"
                variant="outline"
                onClick={() => navigate("/dashboard")}
                className="border-primary/50 text-primary hover:bg-primary/10 hover:scale-105 transition-all duration-300"
              >
                <Shield className="w-5 h-5 mr-2" />
                Security Dashboard
              </Button>
            </div>
          </div>

          {/* Features Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            {features.map((feature, index) => {
              const Icon = feature.icon
              return (
                <CyberCard 
                  key={index} 
                  variant="glow"
                  className="text-center hover:scale-105 transition-transform duration-300"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center mx-auto mb-4">
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </CyberCard>
              )
            })}
          </div>

          {/* What You'll Learn */}
          <CyberCard variant="glow" className="max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold mb-6 text-center gradient-text">
              What You'll Learn
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mt-1">
                    <span className="text-xs font-bold text-primary">1</span>
                  </div>
                  <div>
                    <h3 className="font-semibold">AI in Cybersecurity Basics</h3>
                    <p className="text-sm text-muted-foreground">Understanding AI's role in threat detection and prevention</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mt-1">
                    <span className="text-xs font-bold text-primary">2</span>
                  </div>
                  <div>
                    <h3 className="font-semibold">Phishing & Threat Simulation</h3>
                    <p className="text-sm text-muted-foreground">Hands-on practice identifying malicious emails and links</p>
                  </div>
                </div>
              </div>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mt-1">
                    <span className="text-xs font-bold text-primary">3</span>
                  </div>
                  <div>
                    <h3 className="font-semibold">AI Security Tools</h3>
                    <p className="text-sm text-muted-foreground">Learn about real-world AI-powered cybersecurity platforms</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mt-1">
                    <span className="text-xs font-bold text-primary">4</span>
                  </div>
                  <div>
                    <h3 className="font-semibold">Social Engineering Defense</h3>
                    <p className="text-sm text-muted-foreground">Protect against human-based attacks and manipulation tactics</p>
                  </div>
                </div>
              </div>
            </div>
          </CyberCard>
        </div>
      </main>
    </div>
  )
}

export default Index

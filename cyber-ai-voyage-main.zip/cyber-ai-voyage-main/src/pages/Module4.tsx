import { useState } from "react"
import { Navigation } from "@/components/layout/navigation"
import { CyberCard } from "@/components/ui/cyber-card"
import { ScenarioCard } from "@/components/scenario/scenario-card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { useProgress } from "@/hooks/use-progress"
import { useNavigate } from "react-router-dom"
import { Users, CheckCircle, ArrowLeft, ArrowRight, AlertTriangle, Phone, Shield, User } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

const Module4 = () => {
  const navigate = useNavigate()
  const { toast } = useToast()
  const { completeModule, recordScenarioResult, isModuleCompleted } = useProgress()
  const [reflection, setReflection] = useState("")
  const [scenarioCompleted, setScenarioCompleted] = useState(false)
  const [reflectionSubmitted, setReflectionSubmitted] = useState(false)
  const moduleCompleted = isModuleCompleted("module4")

  const handleScenarioComplete = (goodChoice: boolean) => {
    recordScenarioResult("ceo-fraud", goodChoice)
    setScenarioCompleted(true)
    
    if (goodChoice) {
      toast({
        title: "Excellent Security Awareness!",
        description: "You successfully avoided the social engineering attack.",
      })
    } else {
      toast({
        title: "Learning Experience",
        description: "Social engineering attacks rely on urgency and authority. Always verify!",
        variant: "destructive"
      })
    }
  }

  const handleReflectionSubmit = () => {
    if (reflection.trim().length < 20) {
      toast({
        title: "Please provide more detail",
        description: "Your reflection should be at least 20 characters long.",
        variant: "destructive"
      })
      return
    }
    
    setReflectionSubmitted(true)
    if (scenarioCompleted) {
      completeModule("module4")
      toast({
        title: "Module 4 Complete!",
        description: "You've mastered social engineering defense strategies.",
      })
    }
  }

  const socialEngineeringTactics = [
    {
      name: "Authority",
      icon: User,
      description: "Impersonating authority figures like bosses, IT staff, or government officials",
      example: "Caller claims to be from IT requesting password for 'security audit'"
    },
    {
      name: "Urgency",
      icon: AlertTriangle,
      description: "Creating artificial time pressure to bypass normal security procedures",
      example: "Email demanding immediate action to 'prevent account closure'"
    },
    {
      name: "Fear",
      icon: Shield,
      description: "Threatening negative consequences if the victim doesn't comply",
      example: "Warning that accounts will be suspended unless verification is completed"
    },
    {
      name: "Trust",
      icon: Phone,
      description: "Building rapport and appearing helpful or trustworthy",
      example: "Friendly caller offering to 'help' resolve a non-existent technical issue"
    }
  ]

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <main className="pt-20 pb-12">
        <div className="container mx-auto px-4 max-w-4xl">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 rounded-lg bg-accent/20 flex items-center justify-center">
                <Users className="w-5 h-5 text-accent" />
              </div>
              <h1 className="text-3xl font-bold gradient-text">Module 4: Behavioral Threats (Social Engineering)</h1>
            </div>
            {moduleCompleted && (
              <div className="inline-flex items-center space-x-2 text-success">
                <CheckCircle className="w-5 h-5" />
                <span className="font-medium">Completed</span>
              </div>
            )}
          </div>

          <div className="space-y-8">
            {/* Introduction */}
            <CyberCard variant="glow">
              <h2 className="text-xl font-semibold mb-4 text-primary">Understanding Social Engineering</h2>
              <div className="space-y-4 text-muted-foreground">
                <p>
                  Social engineering attacks target the human element of security, exploiting psychological 
                  manipulation rather than technical vulnerabilities. These attacks are often more effective 
                  than technical exploits because they bypass security systems by tricking people.
                </p>
                
                <div className="p-4 rounded-lg bg-warning/5 border border-warning/20">
                  <div className="flex items-center space-x-2 mb-2">
                    <AlertTriangle className="w-5 h-5 text-warning" />
                    <span className="font-semibold text-warning">Key Insight</span>
                  </div>
                  <p className="text-sm">
                    Social engineering succeeds through urgency, authority, fear, and trust. 
                    Attackers create scenarios that pressure victims into bypassing normal security procedures.
                  </p>
                </div>

                <h3 className="text-lg font-semibold text-foreground mt-6 mb-3">Common Social Engineering Tactics:</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  {socialEngineeringTactics.map((tactic, index) => {
                    const Icon = tactic.icon
                    return (
                      <div key={index} className="p-4 rounded-lg bg-card-hover border border-border">
                        <div className="flex items-center space-x-2 mb-2">
                          <Icon className="w-5 h-5 text-primary" />
                          <h4 className="font-semibold">{tactic.name}</h4>
                        </div>
                        <p className="text-sm mb-2">{tactic.description}</p>
                        <p className="text-xs text-muted-foreground italic">
                          Example: {tactic.example}
                        </p>
                      </div>
                    )
                  })}
                </div>
              </div>
            </CyberCard>

            {/* Interactive Scenario */}
            <ScenarioCard
              title="CEO Fraud Scenario"
              scenario="You're working as an administrative assistant when you receive an urgent email that appears to be from your company's CEO. The email states: 'I'm in an important client meeting and need you to urgently transfer $25,000 to our new vendor for a critical project. Time is of the essence - the deal depends on this payment being made within the next hour. I'll be unreachable by phone for the rest of the day. Please confirm when the transfer is complete. Thanks for your quick action on this.' The email comes from an address that looks like the CEO's but has a subtle difference: ceo@yourcompany-corp.com instead of ceo@yourcompany.com."
              options={[
                {
                  id: "transfer",
                  text: "Transfer the money immediately as requested",
                  outcome: "This was a social engineering attack! The subtle email difference and urgency were red flags. You've just transferred money to a fraudster. CEO fraud attacks often succeed because they exploit authority and urgency to bypass normal verification procedures.",
                  isGoodChoice: false
                },
                {
                  id: "call",
                  text: "Call the CEO directly to verify the request",
                  outcome: "Excellent! You correctly identified the red flags and followed proper verification procedures. By calling directly, you would discover this is fraudulent. This is exactly the right response to any unusual financial request, regardless of apparent authority.",
                  isGoodChoice: true
                },
                {
                  id: "ignore",
                  text: "Ignore the email since it seems suspicious",
                  outcome: "While your suspicion is good, simply ignoring isn't the best approach. You should report this to your IT security team and potentially alert the real CEO that someone is impersonating them.",
                  isGoodChoice: false
                },
                {
                  id: "respond",
                  text: "Reply asking for more information and confirmation",
                  outcome: "Risky approach! Responding to the fraudulent email confirms your email is active and may lead to more sophisticated follow-up attacks. The better approach is to verify through a separate, trusted communication channel.",
                  isGoodChoice: false
                }
              ]}
              onComplete={handleScenarioComplete}
            />

            {/* Defense Strategies */}
            <CyberCard variant="glow">
              <h3 className="text-xl font-semibold mb-4 text-primary">Defense Strategies</h3>
              <div className="space-y-4">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <h4 className="font-semibold text-success">✓ Do This</h4>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li>• Verify requests through separate channels</li>
                      <li>• Question urgent or unusual requests</li>
                      <li>• Report suspicious communications</li>
                      <li>• Use multi-person approval for sensitive actions</li>
                      <li>• Trust your instincts when something feels wrong</li>
                      <li>• Establish clear verification procedures</li>
                    </ul>
                  </div>
                  <div className="space-y-3">
                    <h4 className="font-semibold text-destructive">✗ Avoid This</h4>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li>• Acting on urgent requests without verification</li>
                      <li>• Providing sensitive information over email/phone</li>
                      <li>• Bypassing security procedures for "VIPs"</li>
                      <li>• Clicking links in suspicious emails</li>
                      <li>• Sharing personal information on social media</li>
                      <li>• Ignoring security training and policies</li>
                    </ul>
                  </div>
                </div>

                <div className="p-4 rounded-lg bg-primary/5 border border-primary/20 mt-6">
                  <h4 className="font-semibold text-primary mb-2">The Golden Rule</h4>
                  <p className="text-sm">
                    <strong>When in doubt, verify!</strong> No legitimate organization will pressure you 
                    to bypass security procedures. Take time to verify through official channels.
                  </p>
                </div>
              </div>
            </CyberCard>

            {/* Reflection Exercise */}
            <CyberCard variant="glow">
              <h3 className="text-xl font-semibold mb-4 text-primary">Workplace Verification Process</h3>
              <p className="text-muted-foreground mb-4">
                Write down how you would verify any sensitive request in your workplace. Consider what 
                steps you would take, who you would contact, and what information you would need to 
                confirm before taking action:
              </p>
              <Textarea
                placeholder="Describe your verification process for sensitive workplace requests..."
                value={reflection}
                onChange={(e) => setReflection(e.target.value)}
                className="mb-4"
                rows={5}
                disabled={reflectionSubmitted}
              />
              {!reflectionSubmitted ? (
                <Button 
                  onClick={handleReflectionSubmit} 
                  disabled={reflection.trim().length < 20 || !scenarioCompleted}
                >
                  Submit Verification Process
                </Button>
              ) : (
                <div className="flex items-center space-x-2 text-success">
                  <CheckCircle className="w-5 h-5" />
                  <span>Verification process documented successfully!</span>
                </div>
              )}
              {!scenarioCompleted && (
                <p className="text-sm text-muted-foreground mt-2">
                  Complete the scenario above first, then submit your verification process.
                </p>
              )}
            </CyberCard>

            {/* Navigation */}
            <div className="flex justify-between">
              <Button variant="outline" onClick={() => navigate("/module3")}>
                <ArrowLeft className="w-4 h-4 mr-2" /> Previous: AI Tools
              </Button>
              <Button 
                onClick={() => navigate("/progress")}
                disabled={!moduleCompleted}
                className="disabled:opacity-50"
              >
                View Progress <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

export default Module4
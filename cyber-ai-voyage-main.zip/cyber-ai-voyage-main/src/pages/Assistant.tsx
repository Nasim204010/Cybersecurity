import { Navigation } from "@/components/layout/navigation"
import { CyberCard } from "@/components/ui/cyber-card"
import { Button } from "@/components/ui/button"
import { useNavigate } from "react-router-dom"
import { Bot, ExternalLink, Home, MessageCircle, Brain, Shield, Search, HelpCircle } from "lucide-react"

const Assistant = () => {
  const navigate = useNavigate()

  const aiFeatures = [
    {
      icon: MessageCircle,
      title: "Natural Language Q&A",
      description: "Ask questions about cybersecurity in plain English"
    },
    {
      icon: Brain,
      title: "AI-Powered Insights",
      description: "Get intelligent explanations of complex security concepts"
    },
    {
      icon: Shield,
      title: "Threat Analysis",
      description: "Understand current cybersecurity threats and defenses"
    },
    {
      icon: Search,
      title: "Best Practices",
      description: "Learn industry-standard security practices and procedures"
    }
  ]

  const sampleQuestions = [
    "What are the signs of a phishing email?",
    "How does AI help in cybersecurity?",
    "What should I do if I suspect a security breach?",
    "How can I create stronger passwords?",
    "What is multi-factor authentication?",
    "How do social engineering attacks work?"
  ]

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <main className="pt-20 pb-12">
        <div className="container mx-auto px-4 max-w-4xl">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 rounded-lg bg-accent/20 flex items-center justify-center">
                <Bot className="w-5 h-5 text-accent" />
              </div>
              <h1 className="text-3xl font-bold gradient-text">AI Cybersecurity Assistant</h1>
            </div>
            <p className="text-muted-foreground">
              Get instant help with cybersecurity questions from our AI-powered assistant
            </p>
          </div>

          <div className="space-y-8">
            {/* Main Assistant Interface */}
            <CyberCard variant="glow" className="text-center">
              <div className="mb-6">
                <div className="w-16 h-16 rounded-full bg-gradient-primary flex items-center justify-center mx-auto mb-4 neon-glow">
                  <Bot className="w-8 h-8 text-primary-foreground" />
                </div>
                <h2 className="text-2xl font-bold mb-2">Ask the Cybersecurity AI</h2>
                <p className="text-muted-foreground mb-6">
                  Need help with cybersecurity concepts, threat identification, or best practices? 
                  Our AI assistant is here to provide expert guidance 24/7.
                </p>
              </div>

              {/* Placeholder for chatbot integration */}
              <div className="p-8 rounded-lg bg-muted/30 border border-dashed border-primary/30 mb-6">
                <Bot className="w-12 h-12 text-primary mx-auto mb-4" />
                <p className="text-muted-foreground mb-4">
                  AI Assistant integration would be embedded here
                </p>
                <p className="text-sm text-muted-foreground">
                  Connect with Chatbase, Landbot, or your preferred AI chatbot service
                </p>
              </div>

              <div className="space-y-3">
                <Button 
                  size="lg"
                  onClick={() => window.open('https://chatbase.co', '_blank')}
                  className="w-full sm:w-auto"
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Launch AI Assistant
                </Button>
                <p className="text-xs text-muted-foreground">
                  Powered by advanced AI (External Service)
                </p>
              </div>
            </CyberCard>

            {/* Features */}
            <CyberCard variant="glow">
              <h3 className="text-xl font-semibold mb-6 text-primary">AI Assistant Features</h3>
              <div className="grid md:grid-cols-2 gap-6">
                {aiFeatures.map((feature, index) => {
                  const Icon = feature.icon
                  return (
                    <div key={index} className="flex items-start space-x-3">
                      <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center mt-1">
                        <Icon className="w-4 h-4 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-semibold mb-1">{feature.title}</h4>
                        <p className="text-sm text-muted-foreground">{feature.description}</p>
                      </div>
                    </div>
                  )
                })}
              </div>
            </CyberCard>

            {/* Sample Questions */}
            <CyberCard variant="glow">
              <h3 className="text-xl font-semibold mb-6 text-primary">Sample Questions to Try</h3>
              <div className="grid md:grid-cols-2 gap-3">
                {sampleQuestions.map((question, index) => (
                  <button
                    key={index}
                    className="p-3 text-left rounded-lg border border-border hover:bg-card-hover hover:border-primary/30 transition-all duration-200 group"
                    onClick={() => {
                      // In a real implementation, this would populate the chat with the question
                      console.log("Selected question:", question)
                    }}
                  >
                    <div className="flex items-start space-x-2">
                      <HelpCircle className="w-4 h-4 text-primary mt-0.5 group-hover:text-primary-glow transition-colors" />
                      <span className="text-sm">{question}</span>
                    </div>
                  </button>
                ))}
              </div>
            </CyberCard>

            {/* Integration Instructions */}
            <CyberCard variant="glow">
              <h3 className="text-xl font-semibold mb-4 text-primary">For Administrators</h3>
              <div className="space-y-4 text-muted-foreground">
                <p>
                  To integrate your AI chatbot service, replace the placeholder above with your embedded 
                  chatbot widget code. Popular options include:
                </p>
                
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="p-4 rounded-lg bg-card-hover border border-border">
                    <h4 className="font-semibold text-foreground mb-2">Chatbase</h4>
                    <p className="text-sm">Custom AI trained on cybersecurity knowledge</p>
                  </div>
                  <div className="p-4 rounded-lg bg-card-hover border border-border">
                    <h4 className="font-semibold text-foreground mb-2">Landbot</h4>
                    <p className="text-sm">Conversational AI with security focus</p>
                  </div>
                  <div className="p-4 rounded-lg bg-card-hover border border-border">
                    <h4 className="font-semibold text-foreground mb-2">Custom API</h4>
                    <p className="text-sm">Integrate your own AI service</p>
                  </div>
                </div>

                <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
                  <h4 className="font-semibold text-primary mb-2">Implementation Note</h4>
                  <p className="text-sm">
                    Replace the placeholder div above with your chatbot's embed code or widget. 
                    Ensure the AI is trained on cybersecurity content for accurate responses.
                  </p>
                </div>
              </div>
            </CyberCard>

            {/* Navigation */}
            <div className="text-center">
              <Button variant="outline" onClick={() => navigate("/")}>
                <Home className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

export default Assistant
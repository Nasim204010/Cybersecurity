import { Navigation } from "@/components/layout/navigation"
import { CyberCard } from "@/components/ui/cyber-card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useNavigate } from "react-router-dom"
import { MessageSquare, Mail, Phone, ExternalLink, Send, Home } from "lucide-react"
import { useState } from "react"
import { useToast } from "@/hooks/use-toast"

const Contact = () => {
  const navigate = useNavigate()
  const { toast } = useToast()
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: ""
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // In a real implementation, this would submit to your backend or form service
    toast({
      title: "Message Sent!",
      description: "Thank you for your feedback. We'll get back to you soon.",
    })
    setFormData({ name: "", email: "", subject: "", message: "" })
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }))
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <main className="pt-20 pb-12">
        <div className="container mx-auto px-4 max-w-4xl">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 rounded-lg bg-secondary/20 flex items-center justify-center">
                <MessageSquare className="w-5 h-5 text-secondary" />
              </div>
              <h1 className="text-3xl font-bold gradient-text">Contact & Support</h1>
            </div>
            <p className="text-muted-foreground">
              Have questions about cybersecurity or need technical support? We're here to help!
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Contact Form */}
            <CyberCard variant="glow">
              <h2 className="text-xl font-semibold mb-6 text-primary">Send us a Message</h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium mb-2">Name</label>
                    <Input
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="Your full name"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium mb-2">Email</label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="your.email@company.com"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="subject" className="block text-sm font-medium mb-2">Subject</label>
                  <Input
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    placeholder="What is your inquiry about?"
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="message" className="block text-sm font-medium mb-2">Message</label>
                  <Textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Please describe your question or issue in detail..."
                    rows={5}
                    required
                  />
                </div>
                
                <Button type="submit" className="w-full">
                  <Send className="w-4 h-4 mr-2" />
                  Send Message
                </Button>
              </form>
            </CyberCard>

            {/* Contact Information & Resources */}
            <div className="space-y-6">
              {/* Contact Methods */}
              <CyberCard variant="glow">
                <h3 className="text-lg font-semibold mb-4 text-primary">Get in Touch</h3>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
                      <Mail className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-medium">Email Support</h4>
                      <p className="text-sm text-muted-foreground">nasim.albalushi@utas.edu.om</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 rounded-lg bg-secondary/20 flex items-center justify-center">
                      <Phone className="w-4 h-4 text-secondary" />
                    </div>
                    <div>
                      <h4 className="font-medium">Phone Support</h4>
                      <p className="text-sm text-muted-foreground">+968 93960271</p>
                    </div>
                  </div>
                </div>
              </CyberCard>

              {/* External Resources */}
              <CyberCard variant="glow">
                <h3 className="text-lg font-semibold mb-4 text-primary">Additional Resources</h3>
                <div className="space-y-3">
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={() => window.open('https://docs.google.com/forms', '_blank')}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Submit Detailed Feedback Form
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={() => window.open('https://www.cisa.gov/cybersecurity', '_blank')}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    CISA Cybersecurity Resources
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={() => window.open('https://www.sans.org/security-awareness-training/', '_blank')}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    SANS Security Awareness
                  </Button>
                </div>
              </CyberCard>

              {/* FAQ Section */}
              <CyberCard variant="glow">
                <h3 className="text-lg font-semibold mb-4 text-primary">Frequently Asked Questions</h3>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-2">How often should I take this training?</h4>
                    <p className="text-sm text-muted-foreground">
                      We recommend reviewing the modules quarterly or whenever new threats emerge in your industry.
                    </p>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2">Can I track my team's progress?</h4>
                    <p className="text-sm text-muted-foreground">
                      Contact your administrator about enterprise reporting features for tracking team progress and performance.
                    </p>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2">What should I do if I encounter a real threat?</h4>
                    <p className="text-sm text-muted-foreground">
                      Immediately report to your IT security team and follow your organization's incident response procedures.
                    </p>
                  </div>
                </div>
              </CyberCard>
            </div>
          </div>

          {/* Navigation */}
          <div className="mt-8 text-center">
            <Button variant="outline" onClick={() => navigate("/")}>
              <Home className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </div>
        </div>
      </main>
    </div>
  )
}

export default Contact
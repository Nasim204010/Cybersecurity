import { Navigation } from "@/components/layout/navigation"
import { CyberCard } from "@/components/ui/cyber-card"
import { ProgressIndicator } from "@/components/ui/progress-indicator"
import { Button } from "@/components/ui/button"
import { useProgress } from "@/hooks/use-progress"
import { useNavigate } from "react-router-dom"
import { BarChart3, CheckCircle, XCircle, Clock, Trophy, RotateCcw, Home } from "lucide-react"
import { useState } from "react"
import { useToast } from "@/hooks/use-toast"

const Progress = () => {
  const navigate = useNavigate()
  const { toast } = useToast()
  const { progress, resetProgress } = useProgress()
  const [showResetConfirm, setShowResetConfirm] = useState(false)

  const modules = [
    { id: "module1", name: "AI Basics", path: "/module1" },
    { id: "module2", name: "Threat Simulation", path: "/module2" },
    { id: "module3", name: "AI Tools", path: "/module3" },
    { id: "module4", name: "Social Engineering", path: "/module4" }
  ]

  const handleReset = () => {
    resetProgress()
    setShowResetConfirm(false)
    toast({
      title: "Progress Reset",
      description: "All progress has been cleared. You can start fresh!",
    })
  }

  const completedCount = progress.completedModules.length
  const allCompleted = completedCount === modules.length

  const quizScores = Object.values(progress.quizScores)
  const correctQuizzes = quizScores.filter(score => score).length
  const totalQuizzes = quizScores.length

  const scenarioResults = Object.values(progress.scenarioResults)
  const goodScenarios = scenarioResults.filter(result => result).length
  const totalScenarios = scenarioResults.length

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <main className="pt-20 pb-12">
        <div className="container mx-auto px-4 max-w-4xl">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
                <BarChart3 className="w-5 h-5 text-primary" />
              </div>
              <h1 className="text-3xl font-bold gradient-text">Your Progress</h1>
            </div>
            {allCompleted && (
              <div className="flex items-center justify-center space-x-2 text-success mb-4">
                <Trophy className="w-6 h-6" />
                <span className="text-lg font-semibold">Congratulations! All modules completed!</span>
              </div>
            )}
          </div>

          <div className="space-y-8">
            {/* Overall Progress */}
            <CyberCard variant="glow">
              <h2 className="text-xl font-semibold mb-6 text-primary">Overall Progress</h2>
              <ProgressIndicator current={completedCount} total={modules.length} />
              
              {allCompleted && (
                <div className="mt-6 p-4 rounded-lg bg-success/5 border border-success/20">
                  <div className="flex items-center space-x-2 mb-2">
                    <Trophy className="w-5 h-5 text-success" />
                    <span className="font-semibold text-success">Training Complete!</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    You're now better equipped to detect and respond to cyber threats using AI. 
                    Continue practicing these skills in your daily work to maintain strong security awareness.
                  </p>
                </div>
              )}
            </CyberCard>

            {/* Module Progress */}
            <CyberCard variant="glow">
              <h2 className="text-xl font-semibold mb-6 text-primary">Module Progress</h2>
              <div className="space-y-4">
                {modules.map((module, index) => {
                  const isCompleted = progress.completedModules.includes(module.id)
                  return (
                    <div key={module.id} className="flex items-center justify-between p-4 rounded-lg bg-card-hover border border-border">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                          <span className="text-sm font-bold text-primary">{index + 1}</span>
                        </div>
                        <div>
                          <h3 className="font-semibold">{module.name}</h3>
                          <p className="text-sm text-muted-foreground">
                            {isCompleted ? "Completed" : "Not started"}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        {isCompleted ? (
                          <CheckCircle className="w-6 h-6 text-success" />
                        ) : (
                          <Clock className="w-6 h-6 text-muted-foreground" />
                        )}
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => navigate(module.path)}
                        >
                          {isCompleted ? "Review" : "Start"}
                        </Button>
                      </div>
                    </div>
                  )
                })}
              </div>
            </CyberCard>

            {/* Performance Stats */}
            <div className="grid md:grid-cols-2 gap-6">
              <CyberCard variant="glow">
                <h3 className="text-lg font-semibold mb-4 text-primary">Quiz Performance</h3>
                {totalQuizzes > 0 ? (
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Correct Answers</span>
                      <span className="font-semibold">{correctQuizzes}/{totalQuizzes}</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div 
                        className="h-full bg-gradient-primary rounded-full transition-all duration-500"
                        style={{ width: `${totalQuizzes > 0 ? (correctQuizzes / totalQuizzes) * 100 : 0}%` }}
                      />
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {correctQuizzes === totalQuizzes ? "Perfect score!" : "Keep practicing to improve your understanding."}
                    </p>
                  </div>
                ) : (
                  <p className="text-muted-foreground">No quizzes completed yet.</p>
                )}
              </CyberCard>

              <CyberCard variant="glow">
                <h3 className="text-lg font-semibold mb-4 text-primary">Scenario Results</h3>
                {totalScenarios > 0 ? (
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Good Choices</span>
                      <span className="font-semibold">{goodScenarios}/{totalScenarios}</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div 
                        className="h-full bg-gradient-primary rounded-full transition-all duration-500"
                        style={{ width: `${totalScenarios > 0 ? (goodScenarios / totalScenarios) * 100 : 0}%` }}
                      />
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {goodScenarios === totalScenarios ? "Excellent security awareness!" : "Real-world practice builds stronger security instincts."}
                    </p>
                  </div>
                ) : (
                  <p className="text-muted-foreground">No scenarios completed yet.</p>
                )}
              </CyberCard>
            </div>

            {/* Detailed Results */}
            {(totalQuizzes > 0 || totalScenarios > 0) && (
              <CyberCard variant="glow">
                <h3 className="text-lg font-semibold mb-4 text-primary">Detailed Results</h3>
                <div className="space-y-4">
                  {/* Quiz Results */}
                  {Object.entries(progress.quizScores).map(([quizId, correct]) => (
                    <div key={quizId} className="flex items-center justify-between p-3 rounded-lg bg-card-hover">
                      <span className="capitalize">{quizId.replace('-', ' ')}</span>
                      <div className="flex items-center space-x-2">
                        {correct ? (
                          <CheckCircle className="w-5 h-5 text-success" />
                        ) : (
                          <XCircle className="w-5 h-5 text-destructive" />
                        )}
                        <span className="text-sm">{correct ? "Correct" : "Incorrect"}</span>
                      </div>
                    </div>
                  ))}
                  
                  {/* Scenario Results */}
                  {Object.entries(progress.scenarioResults).map(([scenarioId, good]) => (
                    <div key={scenarioId} className="flex items-center justify-between p-3 rounded-lg bg-card-hover">
                      <span className="capitalize">{scenarioId.replace('-', ' ')}</span>
                      <div className="flex items-center space-x-2">
                        {good ? (
                          <CheckCircle className="w-5 h-5 text-success" />
                        ) : (
                          <XCircle className="w-5 h-5 text-destructive" />
                        )}
                        <span className="text-sm">{good ? "Good Choice" : "Learning Experience"}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CyberCard>
            )}

            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button onClick={() => navigate("/")} variant="outline">
                <Home className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
              
              {!showResetConfirm ? (
                <Button 
                  variant="outline" 
                  onClick={() => setShowResetConfirm(true)}
                  className="text-destructive border-destructive hover:bg-destructive/10"
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Reset Progress
                </Button>
              ) : (
                <div className="flex space-x-2">
                  <Button 
                    variant="outline" 
                    onClick={() => setShowResetConfirm(false)}
                  >
                    Cancel
                  </Button>
                  <Button 
                    variant="destructive"
                    onClick={handleReset}
                  >
                    Confirm Reset
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

export default Progress
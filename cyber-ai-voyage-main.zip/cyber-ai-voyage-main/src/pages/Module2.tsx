import { useEffect } from "react"
import { Navigation } from "@/components/layout/navigation"
import { CyberCard } from "@/components/ui/cyber-card"
import { ScenarioCard } from "@/components/scenario/scenario-card"
import { Button } from "@/components/ui/button"
import { useProgress } from "@/hooks/use-progress"
import { useNavigate } from "react-router-dom"
import { Search, CheckCircle, ArrowRight, ArrowLeft, Shield, AlertTriangle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

const Module2 = () => {
  const navigate = useNavigate()
  const { toast } = useToast()
  const { completeModule, recordScenarioResult, isModuleCompleted } = useProgress()
  const moduleCompleted = isModuleCompleted("module2")

  const handleScenarioComplete = (goodChoice: boolean) => {
    recordScenarioResult("phishing-email", goodChoice)
    completeModule("module2")
    
    if (goodChoice) {
      toast({
        title: "Excellent Security Awareness!",
        description: "You successfully identified the phishing attempt.",
      })
    } else {
      toast({
        title: "Learning Opportunity",
        description: "Remember to always verify suspicious requests before taking action.",
        variant: "destructive"
      })
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <main className="pt-20 pb-12">
        <div className="container mx-auto px-4 max-w-4xl">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 rounded-lg bg-warning/20 flex items-center justify-center">
                <Search className="w-5 h-5 text-warning" />
              </div>
              <h1 className="text-3xl font-bold gradient-text">Module 2: Threat Simulation Basics</h1>
            </div>
            {moduleCompleted && (
              <div className="inline-flex items-center space-x-2 text-success">
                <CheckCircle className="w-5 h-5" />
                <span className="font-medium">Completed</span>
              </div>
            )}
          </div>

          <div className="space-y-8">
            {/* Introduction */}
            <CyberCard variant="glow">
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 rounded-full bg-warning/20 flex items-center justify-center mt-1">
                  <AlertTriangle className="w-4 h-4 text-warning" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold mb-4 text-primary">Understanding Phishing Attacks</h2>
                  <div className="space-y-4 text-muted-foreground">
                    <p>
                      Phishing is one of the most common cyber attack methods. Attackers send fraudulent emails 
                      designed to trick recipients into revealing sensitive information or clicking malicious links.
                    </p>
                    
                    <div className="grid md:grid-cols-2 gap-4 my-6">
                      <div className="p-4 rounded-lg bg-destructive/5 border border-destructive/20">
                        <h3 className="font-semibold text-destructive mb-2">Warning Signs</h3>
                        <ul className="text-sm space-y-1">
                          <li>• Urgent or threatening language</li>
                          <li>• Suspicious sender addresses</li>
                          <li>• Unexpected attachments</li>
                          <li>• Requests for sensitive information</li>
                        </ul>
                      </div>
                      <div className="p-4 rounded-lg bg-success/5 border border-success/20">
                        <h3 className="font-semibold text-success mb-2">Best Practices</h3>
                        <ul className="text-sm space-y-1">
                          <li>• Hover over links before clicking</li>
                          <li>• Verify sender identity</li>
                          <li>• Report suspicious emails</li>
                          <li>• Use multi-factor authentication</li>
                        </ul>
                      </div>
                    </div>

                    <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
                      <div className="flex items-center space-x-2 mb-2">
                        <Shield className="w-5 h-5 text-primary" />
                        <span className="font-semibold text-primary">AI Enhancement</span>
                      </div>
                      <p className="text-sm">
                        AI can simulate hundreds of phishing variations for training, helping users like you 
                        prepare for real-world threats by recognizing patterns and red flags across different 
                        attack scenarios.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CyberCard>

            {/* Interactive Scenario */}
            <ScenarioCard
              title="Phishing Email Simulation"
              scenario="You receive an email that appears to be from your company's IT department with the subject line 'URGENT: Account Security Breach - Immediate Action Required'. The email states that your account has been compromised and you must reset your password immediately by clicking the provided link. The sender's email is 'it-security@yourcompany-urgent.com' and the link shows 'https://secure-reset-portal.net/yourcompany' when you hover over it."
              options={[
                {
                  id: "click",
                  text: "Click the link immediately to secure my account",
                  outcome: "Oops! You clicked on a phishing link. The URL doesn't match your company's domain, and the sender address is suspicious. Your credentials could now be at risk. Always verify with IT directly before clicking suspicious links.",
                  isGoodChoice: false
                },
                {
                  id: "hover",
                  text: "Hover over the link and examine the URL carefully",
                  outcome: "Smart move! You noticed the URL doesn't match your company's official domain. This is a clear sign of a phishing attempt. The real company URL would be something like 'yourcompany.com', not 'secure-reset-portal.net'.",
                  isGoodChoice: true
                },
                {
                  id: "ignore",
                  text: "Ignore the email completely",
                  outcome: "While ignoring prevents immediate harm, the better approach is to report suspicious emails to your IT security team so they can protect other employees and improve security measures.",
                  isGoodChoice: false
                },
                {
                  id: "report",
                  text: "Forward the email to IT security and call them to verify",
                  outcome: "Excellent security practice! You've properly verified the suspicious email with your IT team and helped protect your organization. This is exactly what security-aware employees should do.",
                  isGoodChoice: true
                }
              ]}
              onComplete={handleScenarioComplete}
            />

            {/* Key Takeaways */}
            <CyberCard variant="glow">
              <h3 className="text-xl font-semibold mb-4 text-primary">Key Takeaways</h3>
              <div className="space-y-3 text-muted-foreground">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mt-1">
                    <span className="text-xs font-bold text-primary">1</span>
                  </div>
                  <p><strong>Always verify:</strong> Contact IT directly through official channels when in doubt</p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mt-1">
                    <span className="text-xs font-bold text-primary">2</span>
                  </div>
                  <p><strong>Check URLs:</strong> Hover over links to see the actual destination before clicking</p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mt-1">
                    <span className="text-xs font-bold text-primary">3</span>
                  </div>
                  <p><strong>Report threats:</strong> Help protect your organization by reporting suspicious emails</p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mt-1">
                    <span className="text-xs font-bold text-primary">4</span>
                  </div>
                  <p><strong>Trust your instincts:</strong> If something feels wrong, investigate before acting</p>
                </div>
              </div>
            </CyberCard>

            {/* Navigation */}
            <div className="flex justify-between">
              <Button variant="outline" onClick={() => navigate("/module1")}>
                <ArrowLeft className="w-4 h-4 mr-2" /> Previous: AI Basics
              </Button>
              <Button 
                onClick={() => navigate("/module3")}
                disabled={!moduleCompleted}
                className="disabled:opacity-50"
              >
                Next: AI Tools <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

export default Module2
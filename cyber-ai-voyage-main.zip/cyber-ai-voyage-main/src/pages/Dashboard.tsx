import { Navigation } from "@/components/layout/navigation";
import { DashboardMetrics } from "@/components/dashboard/dashboard-metrics";
import { CourseGrid } from "@/components/dashboard/course-grid";
import { SecurityNews } from "@/components/dashboard/security-news";
import { UserProgress } from "@/components/dashboard/user-progress";
import { MatrixBackground } from "@/components/ui/matrix-background";

const Dashboard = () => {
  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <MatrixBackground />
      <Navigation />
      
      <main className="relative z-10 max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold gradient-text mb-2">
            Security Operations Center
          </h1>
          <p className="text-muted-foreground text-lg">
            Monitor your cybersecurity training progress and threat landscape
          </p>
        </div>

        <DashboardMetrics />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">
          <div className="lg:col-span-2">
            <CourseGrid />
          </div>
          <div className="space-y-8">
            <UserProgress />
            <SecurityNews />
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
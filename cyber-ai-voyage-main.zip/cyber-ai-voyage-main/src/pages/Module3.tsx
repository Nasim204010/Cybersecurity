import { useEffect, useState } from "react"
import { Navigation } from "@/components/layout/navigation"
import { CyberCard } from "@/components/ui/cyber-card"
import { QuizCard } from "@/components/quiz/quiz-card"
import { Button } from "@/components/ui/button"
import { useProgress } from "@/hooks/use-progress"
import { useNavigate } from "react-router-dom"
import { Brain, CheckCircle, ArrowRight, ArrowLeft, ExternalLink, Shield, Zap, Eye, Cpu } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

const Module3 = () => {
  const navigate = useNavigate()
  const { toast } = useToast()
  const { completeModule, recordQuizScore, isModuleCompleted } = useProgress()
  const [quizCompleted, setQuizCompleted] = useState(false)
  const moduleCompleted = isModuleCompleted("module3")

  const handleQuizComplete = (correct: boolean) => {
    recordQuizScore("module3-quiz", correct)
    setQuizCompleted(true)
    completeModule("module3")
    
    if (correct) {
      toast({
        title: "Correct!",
        description: "You understand how AI tools detect threats!",
      })
    } else {
      toast({
        title: "Keep Learning",
        description: "Review the AI security tools to understand their capabilities better.",
        variant: "destructive"
      })
    }
  }

  const tools = [
    {
      name: "Darktrace",
      icon: Eye,
      description: "Uses machine learning to detect anomalous behavior in real-time",
      features: ["Behavioral analysis", "Self-learning AI", "Real-time threat detection", "Network visualization"],
      color: "bg-primary/5 border-primary/20 text-primary"
    },
    {
      name: "Microsoft Defender ATP",
      icon: Shield,
      description: "AI-powered endpoint protection and threat hunting",
      features: ["Endpoint detection", "Automated investigation", "Threat intelligence", "Cloud-based protection"],
      color: "bg-secondary/5 border-secondary/20 text-secondary"
    },
    {
      name: "Cylance",
      icon: Cpu,
      description: "Predictive AI that prevents malware before execution",
      features: ["Predictive prevention", "Machine learning models", "Zero-day protection", "Lightweight agent"],
      color: "bg-accent/5 border-accent/20 text-accent"
    },
    {
      name: "IBM Watson for Cybersecurity",
      icon: Zap,
      description: "Cognitive computing for threat intelligence and analysis",
      features: ["Natural language processing", "Threat intelligence", "Security analytics", "Incident response"],
      color: "bg-warning/5 border-warning/20 text-warning"
    }
  ]

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <main className="pt-20 pb-12">
        <div className="container mx-auto px-4 max-w-4xl">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 rounded-lg bg-secondary/20 flex items-center justify-center">
                <Brain className="w-5 h-5 text-secondary" />
              </div>
              <h1 className="text-3xl font-bold gradient-text">Module 3: AI Tools in Threat Detection</h1>
            </div>
            {moduleCompleted && (
              <div className="inline-flex items-center space-x-2 text-success">
                <CheckCircle className="w-5 h-5" />
                <span className="font-medium">Completed</span>
              </div>
            )}
          </div>

          <div className="space-y-8">
            {/* Introduction */}
            <CyberCard variant="glow">
              <h2 className="text-xl font-semibold mb-4 text-primary">How Does AI Detect Threats?</h2>
              <div className="space-y-4 text-muted-foreground">
                <p>
                  AI tools revolutionize cybersecurity by analyzing user behavior, traffic logs, and suspicious 
                  activity in real-time. These systems can process vast amounts of data and identify patterns 
                  that would be impossible for humans to detect manually.
                </p>
                
                <div className="grid md:grid-cols-3 gap-4 my-6">
                  <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
                    <h3 className="font-semibold text-primary mb-2">Behavioral Analysis</h3>
                    <p className="text-sm">Monitors normal user patterns to detect anomalies</p>
                  </div>
                  <div className="p-4 rounded-lg bg-secondary/5 border border-secondary/20">
                    <h3 className="font-semibold text-secondary mb-2">Machine Learning</h3>
                    <p className="text-sm">Continuously learns from new data to improve detection</p>
                  </div>
                  <div className="p-4 rounded-lg bg-accent/5 border border-accent/20">
                    <h3 className="font-semibold text-accent mb-2">Real-time Processing</h3>
                    <p className="text-sm">Analyzes threats as they happen, not after the fact</p>
                  </div>
                </div>

                <h3 className="text-lg font-semibold text-foreground mt-6 mb-3">Key Detection Methods:</h3>
                <ul className="space-y-2">
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span><strong>Signature-based:</strong> Identifies known threat patterns</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span><strong>Anomaly-based:</strong> Detects deviations from normal behavior</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span><strong>Heuristic-based:</strong> Uses rules and algorithms to identify threats</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span><strong>Predictive:</strong> Forecasts potential future attacks</span>
                  </li>
                </ul>
              </div>
            </CyberCard>

            {/* AI Security Tools */}
            <CyberCard variant="glow">
              <h2 className="text-xl font-semibold mb-6 text-primary">Leading AI Security Tools</h2>
              <div className="grid md:grid-cols-2 gap-6">
                {tools.map((tool, index) => {
                  const Icon = tool.icon
                  return (
                    <div key={index} className={`p-4 rounded-lg border ${tool.color}`}>
                      <div className="flex items-center space-x-3 mb-3">
                        <div className="w-8 h-8 rounded-lg bg-current/20 flex items-center justify-center">
                          <Icon className="w-4 h-4" />
                        </div>
                        <h3 className="font-semibold">{tool.name}</h3>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">{tool.description}</p>
                      <ul className="space-y-1">
                        {tool.features.map((feature, idx) => (
                          <li key={idx} className="text-xs flex items-center space-x-2">
                            <span className="w-1 h-1 rounded-full bg-current"></span>
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )
                })}
              </div>
            </CyberCard>

            {/* Quiz Section */}
            <QuizCard
              question="Which tool uses behavioral analysis for real-time threat detection?"
              options={[
                { id: "a", text: "AI Chatbot", isCorrect: false },
                { id: "b", text: "Traditional Firewall", isCorrect: false },
                { id: "c", text: "Darktrace", isCorrect: true },
                { id: "d", text: "Excel Spreadsheet", isCorrect: false }
              ]}
              explanation="Darktrace is specifically designed to use machine learning for behavioral analysis, monitoring network activity to detect anomalous behavior that could indicate a cyber threat. Unlike traditional firewalls that use rule-based filtering, Darktrace learns what's normal for your environment and alerts when something deviates from that baseline."
              onComplete={handleQuizComplete}
            />

            {/* Interactive Demo */}
            <CyberCard variant="glow">
              <h3 className="text-xl font-semibold mb-4 text-primary">Experience AI Detection</h3>
              <p className="text-muted-foreground mb-4">
                Want to see how AI-powered cybersecurity tools work in action? Many vendors offer 
                interactive demos and trial versions of their platforms.
              </p>
              <div className="space-y-3">
                <Button 
                  variant="outline" 
                  className="w-full justify-start"
                  onClick={() => window.open('https://www.darktrace.com/en/demo/', '_blank')}
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Try Darktrace Interactive Demo
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start"
                  onClick={() => window.open('https://www.microsoft.com/en-us/security/business/threat-protection/endpoint-defender', '_blank')}
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Learn About Microsoft Defender ATP
                </Button>
                <p className="text-sm text-muted-foreground">
                  Note: These are external links to vendor websites for educational purposes.
                </p>
              </div>
            </CyberCard>

            {/* Key Insights */}
            <CyberCard variant="glow">
              <h3 className="text-xl font-semibold mb-4 text-primary">Key Insights</h3>
              <div className="space-y-3 text-muted-foreground">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mt-1">
                    <span className="text-xs font-bold text-primary">1</span>
                  </div>
                  <p><strong>Speed advantage:</strong> AI processes security data thousands of times faster than humans</p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mt-1">
                    <span className="text-xs font-bold text-primary">2</span>
                  </div>
                  <p><strong>Pattern recognition:</strong> Identifies subtle attack patterns across massive datasets</p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mt-1">
                    <span className="text-xs font-bold text-primary">3</span>
                  </div>
                  <p><strong>Continuous learning:</strong> Improves detection accuracy with each new threat encountered</p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mt-1">
                    <span className="text-xs font-bold text-primary">4</span>
                  </div>
                  <p><strong>Predictive capabilities:</strong> Can forecast potential attack vectors before they're exploited</p>
                </div>
              </div>
            </CyberCard>

            {/* Navigation */}
            <div className="flex justify-between">
              <Button variant="outline" onClick={() => navigate("/module2")}>
                <ArrowLeft className="w-4 h-4 mr-2" /> Previous: Threat Simulation
              </Button>
              <Button 
                onClick={() => navigate("/module4")}
                disabled={!moduleCompleted}
                className="disabled:opacity-50"
              >
                Next: Social Engineering <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

export default Module3
import { useEffect } from "react"
import { Navigation } from "@/components/layout/navigation"
import { CyberCard } from "@/components/ui/cyber-card"
import { QuizCard } from "@/components/quiz/quiz-card"
import { Button } from "@/components/ui/button"
import { useProgress } from "@/hooks/use-progress"
import { useNavigate } from "react-router-dom"
import { BookOpen, CheckCircle, ArrowRight } from "lucide-react"
import { Textarea } from "@/components/ui/textarea"
import { useState } from "react"
import { useToast } from "@/hooks/use-toast"

const Module1 = () => {
  const navigate = useNavigate()
  const { toast } = useToast()
  const { completeModule, recordQuizScore, isModuleCompleted } = useProgress()
  const [reflection, setReflection] = useState("")
  const [quizCompleted, setQuizCompleted] = useState(false)
  const [reflectionSubmitted, setReflectionSubmitted] = useState(false)
  
  const moduleCompleted = isModuleCompleted("module1")

  const handleQuizComplete = (correct: boolean) => {
    recordQuizScore("module1-quiz", correct)
    setQuizCompleted(true)
    if (correct) {
      toast({
        title: "Correct!",
        description: "Great job understanding AI in cybersecurity!",
      })
    }
  }

  const handleReflectionSubmit = () => {
    if (reflection.trim().length < 10) {
      toast({
        title: "Please provide more detail",
        description: "Your reflection should be at least 10 characters long.",
        variant: "destructive"
      })
      return
    }
    
    setReflectionSubmitted(true)
    toast({
      title: "Reflection submitted!",
      description: "Thank you for sharing your thoughts.",
    })
  }

  useEffect(() => {
    if (quizCompleted && reflectionSubmitted && !moduleCompleted) {
      completeModule("module1")
      toast({
        title: "Module 1 Complete!",
        description: "You've successfully completed Introduction to AI in Cybersecurity.",
      })
    }
  }, [quizCompleted, reflectionSubmitted, moduleCompleted, completeModule, toast])

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <main className="pt-20 pb-12">
        <div className="container mx-auto px-4 max-w-4xl">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-primary" />
              </div>
              <h1 className="text-3xl font-bold gradient-text">Module 1: Introduction to AI in Cybersecurity</h1>
            </div>
            {moduleCompleted && (
              <div className="inline-flex items-center space-x-2 text-success">
                <CheckCircle className="w-5 h-5" />
                <span className="font-medium">Completed</span>
              </div>
            )}
          </div>

          <div className="space-y-8">
            {/* Learning Content */}
            <CyberCard variant="glow">
              <h2 className="text-xl font-semibold mb-4 text-primary">What is AI in Cybersecurity?</h2>
              <div className="space-y-4 text-muted-foreground">
                <p>
                  Artificial Intelligence is revolutionizing how we detect, prevent, and respond to cyber threats. 
                  In this module, you'll learn the fundamentals of AI-powered cybersecurity.
                </p>
                
                <div className="grid md:grid-cols-3 gap-4 my-6">
                  <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
                    <h3 className="font-semibold text-primary mb-2">Fast Analysis</h3>
                    <p className="text-sm">AI can process thousands of security events per second</p>
                  </div>
                  <div className="p-4 rounded-lg bg-secondary/5 border border-secondary/20">
                    <h3 className="font-semibold text-secondary mb-2">Pattern Detection</h3>
                    <p className="text-sm">Identifies subtle patterns humans might miss</p>
                  </div>
                  <div className="p-4 rounded-lg bg-accent/5 border border-accent/20">
                    <h3 className="font-semibold text-accent mb-2">Real-time Alerts</h3>
                    <p className="text-sm">Provides instant notifications of potential threats</p>
                  </div>
                </div>

                <h3 className="text-lg font-semibold text-foreground mt-6 mb-3">Key Benefits:</h3>
                <ul className="space-y-2">
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span><strong>Speed:</strong> Analyzes data faster than human analysts</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span><strong>Accuracy:</strong> Reduces false positives with machine learning</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span><strong>24/7 Monitoring:</strong> Never sleeps, constantly vigilant</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span><strong>Learning:</strong> Improves over time with new data</span>
                  </li>
                </ul>

                <h3 className="text-lg font-semibold text-foreground mt-6 mb-3">Limitations:</h3>
                <ul className="space-y-2">
                  <li className="flex items-start space-x-2">
                    <span className="text-warning mt-1">•</span>
                    <span>Requires large amounts of quality training data</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-warning mt-1">•</span>
                    <span>Can be vulnerable to adversarial attacks</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-warning mt-1">•</span>
                    <span>May struggle with novel or zero-day attacks</span>
                  </li>
                </ul>
              </div>
            </CyberCard>

            {/* Quiz Section */}
            <QuizCard
              question="Which of the following is NOT a benefit of AI in cybersecurity?"
              options={[
                { id: "a", text: "Fast analysis", isCorrect: false },
                { id: "b", text: "Emotional decision-making", isCorrect: true },
                { id: "c", text: "Real-time alerts", isCorrect: false },
                { id: "d", text: "Pattern detection", isCorrect: false }
              ]}
              explanation="AI systems make decisions based on data and algorithms, not emotions. Emotional decision-making can introduce bias and inconsistency, which is why AI's objective approach is actually an advantage in cybersecurity."
              onComplete={handleQuizComplete}
            />

            {/* Reflection Section */}
            <CyberCard variant="glow">
              <h3 className="text-xl font-semibold mb-4 text-primary">Reflection Exercise</h3>
              <p className="text-muted-foreground mb-4">
                In your own words, explain one benefit of using AI in cybersecurity and why it's important:
              </p>
              <Textarea
                placeholder="Share your thoughts on how AI benefits cybersecurity..."
                value={reflection}
                onChange={(e) => setReflection(e.target.value)}
                className="mb-4"
                rows={4}
                disabled={reflectionSubmitted}
              />
              {!reflectionSubmitted ? (
                <Button onClick={handleReflectionSubmit} disabled={reflection.trim().length < 10}>
                  Submit Reflection
                </Button>
              ) : (
                <div className="flex items-center space-x-2 text-success">
                  <CheckCircle className="w-5 h-5" />
                  <span>Reflection submitted successfully!</span>
                </div>
              )}
            </CyberCard>

            {/* Navigation */}
            <div className="flex justify-between">
              <Button variant="outline" onClick={() => navigate("/")}>
                ← Back to Home
              </Button>
              <Button 
                onClick={() => navigate("/module2")}
                disabled={!moduleCompleted}
                className="disabled:opacity-50"
              >
                Next: Threat Simulation <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

export default Module1
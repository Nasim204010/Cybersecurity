import { cn } from "@/lib/utils"
import { ReactNode } from "react"

interface CyberCardProps {
  children: ReactNode
  className?: string
  variant?: "default" | "glow" | "interactive"
  onClick?: () => void
  style?: React.CSSProperties
}

export function CyberCard({ 
  children, 
  className, 
  variant = "default",
  onClick,
  style 
}: CyberCardProps) {
  const baseClasses = "cyber-border rounded-lg p-6 transition-all duration-300"
  
  const variantClasses = {
    default: "card-glow",
    glow: "cyber-glow hover:shadow-glow",
    interactive: "cyber-glow hover:shadow-glow hover:scale-[1.02] cursor-pointer hover:bg-card-hover"
  }

  return (
    <div 
      className={cn(
        baseClasses,
        variantClasses[variant],
        className
      )}
      onClick={onClick}
      style={style}
    >
      {children}
    </div>
  )
}
import { Button } from "@/components/ui/button"
import { useLocation, useNavigate } from "react-router-dom"
import { cn } from "@/lib/utils"
import { Home, BookOpen, Search, Brain, Users, BarChart3, MessageSquare, Bot } from "lucide-react"

const navigationItems = [
  { path: "/", label: "Home", icon: Home },
  { path: "/module1", label: "AI Basics", icon: BookOpen },
  { path: "/module2", label: "Threat Sim", icon: Search },
  { path: "/module3", label: "AI Tools", icon: Brain },
  { path: "/module4", label: "Social Eng", icon: Users },
  { path: "/progress", label: "Progress", icon: BarChart3 },
  { path: "/contact", label: "Contact", icon: MessageSquare },
  { path: "/assistant", label: "AI Assistant", icon: Bot },
]

export function Navigation() {
  const navigate = useNavigate()
  const location = useLocation()

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-primary flex items-center justify-center">
              <Brain className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-bold text-lg gradient-text">Cyber AI Hub</span>
          </div>
          
          <div className="hidden md:flex items-center space-x-1">
            {navigationItems.map((item) => {
              const Icon = item.icon
              const isActive = location.pathname === item.path
              
              return (
                <Button
                  key={item.path}
                  variant={isActive ? "default" : "ghost"}
                  size="sm"
                  onClick={() => navigate(item.path)}
                  className={cn(
                    "flex items-center space-x-2",
                    isActive && "bg-primary/20 text-primary border border-primary/30"
                  )}
                >
                  <Icon className="w-4 h-4" />
                  <span className="hidden lg:inline">{item.label}</span>
                </Button>
              )
            })}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button variant="ghost" size="sm">
              <span className="sr-only">Menu</span>
              ☰
            </Button>
          </div>
        </div>
      </div>
    </nav>
  )
}
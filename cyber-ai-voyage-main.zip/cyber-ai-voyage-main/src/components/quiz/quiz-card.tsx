import { useState } from "react"
import { Button } from "@/components/ui/button"
import { CyberCard } from "@/components/ui/cyber-card"
import { cn } from "@/lib/utils"
import { CheckCircle, XCircle, AlertCircle } from "lucide-react"

interface QuizOption {
  id: string
  text: string
  isCorrect: boolean
}

interface QuizCardProps {
  question: string
  options: QuizOption[]
  explanation?: string
  onComplete?: (correct: boolean) => void
}

export function QuizCard({ question, options, explanation, onComplete }: QuizCardProps) {
  const [selectedOption, setSelectedOption] = useState<string | null>(null)
  const [showResult, setShowResult] = useState(false)

  const handleSubmit = () => {
    if (!selectedOption) return
    
    setShowResult(true)
    const isCorrect = options.find(opt => opt.id === selectedOption)?.isCorrect || false
    onComplete?.(isCorrect)
  }

  const selectedOptionData = options.find(opt => opt.id === selectedOption)
  const isCorrect = selectedOptionData?.isCorrect || false

  return (
    <CyberCard variant="glow" className="space-y-6">
      <div className="flex items-start space-x-3">
        <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center mt-1">
          <AlertCircle className="w-4 h-4 text-primary" />
        </div>
        <div className="flex-1">
          <h3 className="text-lg font-semibold mb-4">{question}</h3>
          
          <div className="space-y-3">
            {options.map((option) => (
              <button
                key={option.id}
                onClick={() => !showResult && setSelectedOption(option.id)}
                disabled={showResult}
                className={cn(
                  "w-full text-left p-4 rounded-lg border transition-all duration-200",
                  "hover:bg-card-hover hover:border-primary/50",
                  selectedOption === option.id && !showResult && "border-primary bg-primary/10",
                  showResult && option.isCorrect && "border-success bg-success/10 text-success",
                  showResult && selectedOption === option.id && !option.isCorrect && "border-destructive bg-destructive/10 text-destructive",
                  showResult && selectedOption !== option.id && !option.isCorrect && "opacity-50",
                  showResult ? "cursor-default" : "cursor-pointer"
                )}
              >
                <div className="flex items-center justify-between">
                  <span>{option.text}</span>
                  {showResult && option.isCorrect && (
                    <CheckCircle className="w-5 h-5 text-success" />
                  )}
                  {showResult && selectedOption === option.id && !option.isCorrect && (
                    <XCircle className="w-5 h-5 text-destructive" />
                  )}
                </div>
              </button>
            ))}
          </div>

          {!showResult && (
            <Button 
              onClick={handleSubmit}
              disabled={!selectedOption}
              className="mt-4 w-full"
            >
              Submit Answer
            </Button>
          )}

          {showResult && explanation && (
            <div className={cn(
              "mt-6 p-4 rounded-lg border-l-4",
              isCorrect ? "border-l-success bg-success/5" : "border-l-warning bg-warning/5"
            )}>
              <p className="text-sm">
                <strong>{isCorrect ? "Correct!" : "Explanation:"}</strong> {explanation}
              </p>
            </div>
          )}
        </div>
      </div>
    </CyberCard>
  )
}
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { CyberCard } from "@/components/ui/cyber-card"
import { cn } from "@/lib/utils"
import { AlertTriangle, CheckCircle, XCircle } from "lucide-react"

interface ScenarioOption {
  id: string
  text: string
  outcome: string
  isGoodChoice: boolean
}

interface ScenarioCardProps {
  title: string
  scenario: string
  options: ScenarioOption[]
  onComplete?: (goodChoice: boolean) => void
}

export function ScenarioCard({ title, scenario, options, onComplete }: ScenarioCardProps) {
  const [selectedOption, setSelectedOption] = useState<string | null>(null)
  const [showOutcome, setShowOutcome] = useState(false)

  const handleChoice = (optionId: string) => {
    setSelectedOption(optionId)
    setShowOutcome(true)
    const option = options.find(opt => opt.id === optionId)
    onComplete?.(option?.isGoodChoice || false)
  }

  const selectedOptionData = options.find(opt => opt.id === selectedOption)

  return (
    <CyberCard variant="glow" className="space-y-6">
      <div className="flex items-start space-x-3">
        <div className="w-8 h-8 rounded-full bg-warning/20 flex items-center justify-center mt-1">
          <AlertTriangle className="w-4 h-4 text-warning" />
        </div>
        <div className="flex-1">
          <h3 className="text-xl font-bold mb-3 text-primary">{title}</h3>
          <p className="text-muted-foreground mb-6 leading-relaxed">{scenario}</p>
          
          {!showOutcome ? (
            <div className="space-y-3">
              <p className="font-semibold mb-4">What do you do?</p>
              {options.map((option) => (
                <Button
                  key={option.id}
                  variant="outline"
                  onClick={() => handleChoice(option.id)}
                  className="w-full justify-start text-left h-auto p-4 whitespace-normal"
                >
                  {option.text}
                </Button>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              <div className={cn(
                "p-4 rounded-lg border-l-4 bg-opacity-10",
                selectedOptionData?.isGoodChoice 
                  ? "border-l-success bg-success text-success-foreground" 
                  : "border-l-destructive bg-destructive text-destructive-foreground"
              )}>
                <div className="flex items-center space-x-2 mb-2">
                  {selectedOptionData?.isGoodChoice ? (
                    <CheckCircle className="w-5 h-5 text-success" />
                  ) : (
                    <XCircle className="w-5 h-5 text-destructive" />
                  )}
                  <span className="font-semibold">
                    {selectedOptionData?.isGoodChoice ? "Good Choice!" : "Risky Choice!"}
                  </span>
                </div>
                <p className="text-sm">{selectedOptionData?.outcome}</p>
              </div>
              
              <div className="text-sm text-muted-foreground">
                <strong>Your choice:</strong> {selectedOptionData?.text}
              </div>
            </div>
          )}
        </div>
      </div>
    </CyberCard>
  )
}
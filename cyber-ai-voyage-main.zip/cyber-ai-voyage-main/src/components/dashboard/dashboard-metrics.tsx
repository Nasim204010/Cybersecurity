import { Shield, AlertTriangle, TrendingUp, Target } from "lucide-react";
import { CyberCard } from "@/components/ui/cyber-card";
import { Progress } from "@/components/ui/progress";

const metrics = [
  {
    title: "Security Score",
    value: "87%",
    icon: Shield,
    description: "Overall cybersecurity knowledge",
    progress: 87,
    trend: "+5%",
    color: "text-primary",
  },
  {
    title: "Threat Awareness",
    value: "92%",
    icon: AlertTriangle,
    description: "Current threat recognition",
    progress: 92,
    trend: "+12%",
    color: "text-warning",
  },
  {
    title: "Skills Progress",
    value: "74%",
    icon: TrendingUp,
    description: "Technical competency growth",
    progress: 74,
    trend: "+8%",
    color: "text-success",
  },
  {
    title: "Certification",
    value: "3/5",
    icon: Target,
    description: "Completed certifications",
    progress: 60,
    trend: "+1",
    color: "text-accent",
  },
];

export const DashboardMetrics = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {metrics.map((metric) => (
        <CyberCard key={metric.title} variant="glow" className="relative overflow-hidden">
          <div className="flex items-start justify-between mb-4">
            <div className="p-2 rounded-lg bg-card">
              <metric.icon className={`h-6 w-6 ${metric.color}`} />
            </div>
            <div className={`text-sm font-medium ${metric.color}`}>
              {metric.trend}
            </div>
          </div>
          
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-muted-foreground">
              {metric.title}
            </h3>
            <div className="text-2xl font-bold text-card-foreground">
              {metric.value}
            </div>
            <p className="text-xs text-muted-foreground">
              {metric.description}
            </p>
            <div className="mt-3">
              <Progress value={metric.progress} className="h-2" />
            </div>
          </div>
        </CyberCard>
      ))}
    </div>
  );
};
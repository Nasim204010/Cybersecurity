import { Book, Clock, Users, Star, ChevronRight } from "lucide-react";
import { CyberCard } from "@/components/ui/cyber-card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

const courses = [
  {
    id: 1,
    title: "Advanced Threat Detection",
    description: "Learn to identify and analyze sophisticated cyber threats using AI-powered tools",
    level: "Advanced",
    duration: "6 hours",
    enrolled: 1247,
    rating: 4.9,
    progress: 0,
    category: "AI Security",
    image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=400&h=200&fit=crop",
  },
  {
    id: 2,
    title: "Social Engineering Defense",
    description: "Master the psychology behind social engineering attacks and build robust defenses",
    level: "Intermediate",
    duration: "4 hours",
    enrolled: 2156,
    rating: 4.8,
    progress: 34,
    category: "Human Factor",
    image: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=400&h=200&fit=crop",
  },
  {
    id: 3,
    title: "Zero Trust Architecture",
    description: "Design and implement zero trust security models for modern enterprises",
    level: "Expert",
    duration: "8 hours",
    enrolled: 892,
    rating: 4.9,
    progress: 67,
    category: "Architecture",
    image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=400&h=200&fit=crop",
  },
  {
    id: 4,
    title: "Incident Response Automation",
    description: "Automate incident response workflows using AI and machine learning",
    level: "Advanced",
    duration: "5 hours",
    enrolled: 1089,
    rating: 4.7,
    progress: 12,
    category: "Automation",
    image: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=200&fit=crop",
  },
];

const getLevelColor = (level: string) => {
  switch (level) {
    case "Beginner": return "bg-success/20 text-success";
    case "Intermediate": return "bg-warning/20 text-warning";
    case "Advanced": return "bg-primary/20 text-primary";
    case "Expert": return "bg-destructive/20 text-destructive";
    default: return "bg-muted/20 text-muted-foreground";
  }
};

export const CourseGrid = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-card-foreground">
          AI-Recommended Courses
        </h2>
        <Button variant="outline" className="border-primary/50 text-primary hover:bg-primary/10">
          View All
          <ChevronRight className="ml-2 h-4 w-4" />
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {courses.map((course) => (
          <CyberCard key={course.id} variant="interactive" className="group">
            <div className="aspect-video rounded-lg overflow-hidden mb-4">
              <img
                src={course.image}
                alt={course.title}
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Badge className={getLevelColor(course.level)}>
                  {course.level}
                </Badge>
                <div className="flex items-center gap-1 text-warning">
                  <Star className="h-4 w-4 fill-current" />
                  <span className="text-sm font-medium">{course.rating}</span>
                </div>
              </div>

              <h3 className="text-xl font-bold text-card-foreground group-hover:text-primary transition-colors">
                {course.title}
              </h3>

              <p className="text-muted-foreground text-sm line-clamp-2">
                {course.description}
              </p>

              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  {course.duration}
                </div>
                <div className="flex items-center gap-1">
                  <Users className="h-4 w-4" />
                  {course.enrolled.toLocaleString()}
                </div>
                <div className="flex items-center gap-1">
                  <Book className="h-4 w-4" />
                  {course.category}
                </div>
              </div>

              {course.progress > 0 ? (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Progress</span>
                    <span className="text-primary font-medium">{course.progress}%</span>
                  </div>
                  <Progress value={course.progress} className="h-2" />
                  <Button className="w-full bg-primary hover:bg-primary/90">
                    Continue Learning
                  </Button>
                </div>
              ) : (
                <Button className="w-full bg-primary hover:bg-primary/90">
                  Start Course
                </Button>
              )}
            </div>
          </CyberCard>
        ))}
      </div>
    </div>
  );
};
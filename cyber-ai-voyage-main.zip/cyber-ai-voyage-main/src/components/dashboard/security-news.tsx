import { ExternalLink, AlertCircle, Shield, Bug, Zap } from "lucide-react";
import { CyberCard } from "@/components/ui/cyber-card";
import { Badge } from "@/components/ui/badge";

const newsItems = [
  {
    id: 1,
    title: "Critical Zero-Day in Enterprise VPN Solutions",
    source: "CISA Alert",
    timestamp: "2 hours ago",
    type: "critical",
    icon: AlertCircle,
    description: "New vulnerability affects major VPN vendors, immediate patching recommended.",
  },
  {
    id: 2,
    title: "AI-Powered Phishing Campaigns Surge 340%",
    source: "Threat Intelligence",
    timestamp: "6 hours ago",
    type: "threat",
    icon: Zap,
    description: "Sophisticated AI tools being used to create convincing phishing emails.",
  },
  {
    id: 3,
    title: "New NIST Cybersecurity Framework Guidelines",
    source: "NIST",
    timestamp: "1 day ago",
    type: "update",
    icon: Shield,
    description: "Updated guidelines for implementing cybersecurity frameworks in 2024.",
  },
  {
    id: 4,
    title: "Supply Chain Attack Affects 50+ Organizations",
    source: "Security Research",
    timestamp: "2 days ago",
    type: "incident",
    icon: Bug,
    description: "Compromised software update mechanism leads to widespread breach.",
  },
];

const getTypeColor = (type: string) => {
  switch (type) {
    case "critical": return "bg-destructive/20 text-destructive";
    case "threat": return "bg-warning/20 text-warning";
    case "update": return "bg-primary/20 text-primary";
    case "incident": return "bg-accent/20 text-accent";
    default: return "bg-muted/20 text-muted-foreground";
  }
};

export const SecurityNews = () => {
  return (
    <CyberCard variant="glow">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-card-foreground">
            Security Intelligence
          </h2>
          <Badge variant="outline" className="border-primary/50 text-primary">
            Live Feed
          </Badge>
        </div>

        <div className="space-y-4">
          {newsItems.map((item) => (
            <div
              key={item.id}
              className="group p-4 rounded-lg border border-border bg-card/50 hover:bg-card/80 transition-all duration-200 cursor-pointer"
            >
              <div className="flex items-start gap-3">
                <div className={`p-2 rounded-lg ${getTypeColor(item.type)}`}>
                  <item.icon className="h-4 w-4" />
                </div>
                
                <div className="flex-1 space-y-2">
                  <div className="flex items-start justify-between">
                    <h3 className="text-sm font-medium text-card-foreground group-hover:text-primary transition-colors line-clamp-2">
                      {item.title}
                    </h3>
                    <ExternalLink className="h-3 w-3 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0 ml-2" />
                  </div>
                  
                  <p className="text-xs text-muted-foreground line-clamp-2">
                    {item.description}
                  </p>
                  
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span className="font-medium">{item.source}</span>
                    <span>{item.timestamp}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="pt-4 border-t border-border">
          <div className="text-center">
            <button className="text-sm text-primary hover:text-primary/80 font-medium transition-colors">
              View All Security News →
            </button>
          </div>
        </div>
      </div>
    </CyberCard>
  );
};
import { TrendingUp, Calendar, Trophy, Flame } from "lucide-react";
import { CyberCard } from "@/components/ui/cyber-card";
import { Progress } from "@/components/ui/progress";

const skills = [
  { name: "Threat Analysis", progress: 89, level: "Expert" },
  { name: "Network Security", progress: 76, level: "Advanced" },
  { name: "Incident Response", progress: 62, level: "Intermediate" },
  { name: "AI Security", progress: 45, level: "Beginner" },
];

const achievements = [
  { name: "First Certificate", icon: Trophy, date: "2 days ago" },
  { name: "7-Day Streak", icon: Flame, date: "Today" },
  { name: "Module Master", icon: TrendingUp, date: "1 week ago" },
];

export const UserProgress = () => {
  return (
    <CyberCard variant="glow">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-card-foreground">Your Progress</h2>
          <div className="flex items-center gap-2 text-primary">
            <TrendingUp className="h-5 w-5" />
            <span className="text-sm font-medium">+23% this week</span>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
            Skill Development
          </h3>
          {skills.map((skill) => (
            <div key={skill.name} className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-card-foreground">
                  {skill.name}
                </span>
                <span className="text-xs text-muted-foreground">
                  {skill.level}
                </span>
              </div>
              <Progress value={skill.progress} className="h-2" />
            </div>
          ))}
        </div>

        <div className="space-y-4">
          <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
            Recent Achievements
          </h3>
          {achievements.map((achievement) => (
            <div key={achievement.name} className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <achievement.icon className="h-4 w-4 text-primary" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-card-foreground">
                  {achievement.name}
                </p>
                <p className="text-xs text-muted-foreground">{achievement.date}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-3 gap-4 pt-4 border-t border-border">
          <div className="text-center">
            <div className="text-lg font-bold text-primary">24</div>
            <div className="text-xs text-muted-foreground">Challenges</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-warning">8</div>
            <div className="text-xs text-muted-foreground">Certificates</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-success">156</div>
            <div className="text-xs text-muted-foreground">Points</div>
          </div>
        </div>
      </div>
    </CyberCard>
  );
};
import { useState, useEffect } from "react"

interface Progress {
  completedModules: string[]
  quizScores: Record<string, boolean>
  scenarioResults: Record<string, boolean>
}

const STORAGE_KEY = "cyber-ai-progress"

export function useProgress() {
  const [progress, setProgress] = useState<Progress>({
    completedModules: [],
    quizScores: {},
    scenarioResults: {}
  })

  // Load progress from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY)
    if (saved) {
      try {
        setProgress(JSON.parse(saved))
      } catch (error) {
        console.error("Failed to parse progress data:", error)
      }
    }
  }, [])

  // Save progress to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress))
  }, [progress])

  const completeModule = (moduleId: string) => {
    setProgress(prev => ({
      ...prev,
      completedModules: [...new Set([...prev.completedModules, moduleId])]
    }))
  }

  const recordQuizScore = (quizId: string, correct: boolean) => {
    setProgress(prev => ({
      ...prev,
      quizScores: { ...prev.quizScores, [quizId]: correct }
    }))
  }

  const recordScenarioResult = (scenarioId: string, goodChoice: boolean) => {
    setProgress(prev => ({
      ...prev,
      scenarioResults: { ...prev.scenarioResults, [scenarioId]: goodChoice }
    }))
  }

  const isModuleCompleted = (moduleId: string) => {
    return progress.completedModules.includes(moduleId)
  }

  const getQuizScore = (quizId: string) => {
    return progress.quizScores[quizId]
  }

  const getScenarioResult = (scenarioId: string) => {
    return progress.scenarioResults[scenarioId]
  }

  const getTotalProgress = () => {
    const totalModules = 4
    return progress.completedModules.length / totalModules
  }

  const resetProgress = () => {
    setProgress({
      completedModules: [],
      quizScores: {},
      scenarioResults: {}
    })
  }

  return {
    progress,
    completeModule,
    recordQuizScore,
    recordScenarioResult,
    isModuleCompleted,
    getQuizScore,
    getScenarioResult,
    getTotalProgress,
    resetProgress
  }
}